/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id: DialogoGeneradorCodigo.java,v 1.3 2008/03/09 18:47:38 cupi3 Exp $
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n 
 * Licenciado bajo el esquema Academic Free License version 2.1 
 *
 * Proyecto Cupi2 (http://cupi2.uniandes.edu.co)
 * Ejercicio: Tutorial Generaci�n C�digo (n10_paint)
 * Autor: n-calder
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 */
package uniandes.cupi2.paint.velocity.interfaz;
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import uniandes.cupi2.paint.interfaz.InterfazPaint;

/**
 * Di�logo para la generaci�n de c�digo
 */
public class DialogoGeneradorCodigo extends JDialog implements ActionListener{

	//-----------------------------------------------------------------
    // Constantes
    // -----------------------------------------------------------------

    /**
     * El comando para el bot�n de selecci�n de superclase
     */
    private final String SEL_SUPER = "seleccionar super";

    /**
     * El comando pra el bot�n de selecci�n de interfaces
     */
    private final String SEL_INTERFACES = "seleccionar interfaces";

    /**
     * El comando para el bot�n de generaci�n
     */
    private final String GENERAR = "generar";

    /**
     * El comando para el bot�n cancelar
     */
    private final String CANCELAR = "cancelar";
    
    /**
     * Directorio de C�digo para la seleccion de clases
     */
    private final String SOURCE = "./source";
    
    //-----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------
	/**
	 * Paneles para la presentaci�n de informaci�n y botones
	 */
    private JPanel panelGenerador;
	private JPanel panelBotones;
	
	/**
	 * Elementos para indicar el nombre de la nueva clase
	 */
	private JLabel etiquetaClase;
	private JTextField textoClase;
	
	/**
	 * Elementos para seleccionar la generaci�n basado en superclase
	 */
	private JCheckBox checkSuperClase;
	private JTextField textoSuper;
	private JButton botonSeleccionarSuper;
	
	/**
	 * Elementos para seleccionar la selecci�n con interfaces
	 */
	private JCheckBox checkInterfaces;
	private JTextArea areaInterfaces;
	private JButton botonSeleccionarInterfaces;
		
	/**
	 * Botones de opciones del di�logo
	 */
	private JButton botonCancelar;
	private JButton botonGenerar;
	
	/**
	 * Referencia a la ventana principal
	 */
	private InterfazPaint principal;

	
	//-----------------------------------------------------------------
    // Constructores
    // -----------------------------------------------------------------
	
	/**
	 * Construye un nuevo di�logo hijo de la ventana principal
	 */
	public DialogoGeneradorCodigo(InterfazPaint ventana) 
	{
		super(ventana);
		this.principal = ventana;
		inicializar();
	}

	//-----------------------------------------------------------------
    // M�todos
    // -----------------------------------------------------------------
	
	/**
	 * Construir y ubicar los elementos gr�ficos del di�logo
	 */
	private void inicializar() 
	{

		setTitle("Generador C�digo Paint");
		this.setSize(507, 263);
		this.setLocationRelativeTo(principal);

		panelGenerador = new JPanel();
		GridBagLayout panelGeneradorLayout = new GridBagLayout();
		panelGeneradorLayout.columnWidths = new int[] {7, 7, 193, 7};
		panelGeneradorLayout.rowHeights = new int[] {7, 7, 7, 7};
		panelGeneradorLayout.columnWeights = new double[] {0.1, 0.1, 0.0, 0.1};
		panelGeneradorLayout.rowWeights = new double[] {0.1, 0.1, 0.1, 0.1};
		
		panelGenerador.setLayout(panelGeneradorLayout);	
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		

		checkSuperClase = new JCheckBox();
		panelGenerador.add(checkSuperClase, gbc);
		checkSuperClase.setText("Superclase");
		checkSuperClase.setSelected(true);

		checkInterfaces = new JCheckBox();
		gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		panelGenerador.add(checkInterfaces, gbc);
		checkInterfaces.setText("Interfaces");
		checkInterfaces.setEnabled(false);


		textoSuper = new JTextField();
		gbc = new GridBagConstraints();
		gbc.gridx = 1;
		gbc.gridy = 1;
		gbc.gridwidth = 2;
		gbc.gridheight = 1;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		panelGenerador.add(textoSuper, gbc);


		botonSeleccionarSuper = new JButton();
		gbc = new GridBagConstraints();
		gbc.gridx = 3;
		gbc.gridy = 1;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		panelGenerador.add(botonSeleccionarSuper, gbc);
		botonSeleccionarSuper.setText("Seleccionar");
		botonSeleccionarSuper.setActionCommand(SEL_SUPER);
		botonSeleccionarSuper.addActionListener(this);
		

		areaInterfaces = new JTextArea();
		areaInterfaces.setEnabled(false);
		areaInterfaces.setEditable(false);
		gbc = new GridBagConstraints();
		gbc.gridx = 1;
		gbc.gridy = 2;
		gbc.gridwidth = 2;
		gbc.gridheight = 3;
		gbc.fill = GridBagConstraints.BOTH;
		panelGenerador.add(areaInterfaces, gbc);


		botonSeleccionarInterfaces = new JButton();
		gbc = new GridBagConstraints();
		gbc.gridx = 3;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		panelGenerador.add(botonSeleccionarInterfaces,gbc);
		botonSeleccionarInterfaces.setText("Seleccionar");
		botonSeleccionarInterfaces.setActionCommand(SEL_INTERFACES);
		botonSeleccionarInterfaces.addActionListener(this);
		botonSeleccionarInterfaces.setEnabled(false);


		etiquetaClase = new JLabel();
		gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		panelGenerador.add( etiquetaClase,gbc);
		etiquetaClase.setText("Nueva Clase");


		textoClase = new JTextField();
		gbc = new GridBagConstraints();
		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.gridwidth = 2;
		gbc.gridheight = 1;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		panelGenerador.add(textoClase, gbc);

		panelBotones = new JPanel();
		panelBotones.setBorder(BorderFactory.createTitledBorder("Opciones"));

		botonGenerar = new JButton();
		botonGenerar.setText("Generar");
		botonGenerar.setActionCommand(GENERAR);
		botonGenerar.addActionListener(this);
		panelBotones.add(botonGenerar);

		botonCancelar = new JButton();
		botonCancelar.setText("Cancelar");
		botonCancelar.setActionCommand(CANCELAR);
		botonCancelar.addActionListener(this);
		panelBotones.add(botonCancelar);
		
		add(panelGenerador, BorderLayout.CENTER);
		panelGenerador.setPreferredSize(new java.awt.Dimension(477, 208));
		panelGenerador.setOpaque(false);
		add(panelBotones, BorderLayout.SOUTH);
	}

	/**
	 * Este m�todo responde a las acciones de todos los botones del di�logo
	 */
	public void actionPerformed(ActionEvent event) 
	{
		String comando = event.getActionCommand( );
        if( SEL_INTERFACES.equals( comando ) )
        {
           
        }
        else if( SEL_SUPER.equals( comando ) )
        {
        	JFileChooser fc = new JFileChooser( SOURCE );
            fc.setDialogTitle( "Seleccionar Clase" );
            fc.setMultiSelectionEnabled( false );
            fc.setFileFilter(new FiltroArchivosJava());
            
            int resultado = fc.showOpenDialog( this );

            if( resultado == JFileChooser.APPROVE_OPTION )
            {
                File seleccionado = fc.getSelectedFile( );
                String paquete = convertirRutaPaquete(seleccionado.getAbsolutePath());
                textoSuper.setText(paquete);
            }
            
        }
        else if( GENERAR.equals( comando ) )
        {
            String clase = textoClase.getText();
            String superClase = textoSuper.getText();
            
            if(clase!=null && !clase.equals("") 
            		&& superClase!=null && !superClase.equals(""))
            {
            	principal.invocarGenerador(clase, superClase);
                dispose();
            }
            else
            {
            	JOptionPane.showMessageDialog( this, "Completar Campos Obligatorios", "Error", JOptionPane.ERROR_MESSAGE );
            }
        	
        }
        else if( CANCELAR.equals( comando ) )
        {
            dispose();
        }
		
	}
	
	/**
	 * Deduce la estructura de paquetes del path dado.
	 * <br/>Pre: Se asume que bajo los est�ndares de c�digo cupi2 todos los
	 * paquetes se encuentran en un directorio source
	 * @param path
	 * @return nombre completo de la clase con estructura de paquete
	 */
	private String convertirRutaPaquete(String path)
	{
		String[] directorios = path.split("\\"+File.separator);
		boolean fin = false;
		String paquete ="";
		
		for (int i = 0; i < directorios.length && !fin; i++) {
			
			if(directorios[i].equals("source"))
			{
				fin = true;
				for(int j = i+1; j < directorios.length; j++)
				{
					paquete += directorios[j] + ".";
				}
			}
		}
		
		//Eliminar la extensi�n del archivo (.java)	
		paquete = paquete.substring(0, paquete.length()-6);
		
		return paquete;
	}

}
