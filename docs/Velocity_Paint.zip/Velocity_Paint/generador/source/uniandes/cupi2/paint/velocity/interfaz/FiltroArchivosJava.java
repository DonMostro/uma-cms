/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id: FiltroArchivosJava.java,v 1.1 2008/02/25 06:57:34 cupi3 Exp $
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n 
 * Licenciado bajo el esquema Academic Free License version 2.1 
 *
 * Proyecto Cupi2 (http://cupi2.uniandes.edu.co)
 * Ejercicio: Tutorial Generaci�n C�digo (n10_paint)
 * Autor: n-calder
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 */
package uniandes.cupi2.paint.velocity.interfaz;

import java.io.File;

import javax.swing.filechooser.FileFilter;

/**
 * Filtro para la selecci�n de archivos .java exclusivo
 */
public class FiltroArchivosJava extends FileFilter {

    /**
     * M�todo que verifica si un archivo dado es v�lido seg�n el criterio
     * de este filtro.
     * @param f archivo a evaluar
     */
    public boolean accept(File f) 
    {
    	if(f.isDirectory())
    		return true;
    	
    	String nombre = f.getName();
    	int punto = nombre.lastIndexOf('.');
    	String extension = nombre.substring(punto+1);
    	
    	if(extension.equals("java"))
    		return true;

        return false;
    }

    /**
     * Retorna la descripci�n que se muestra en el filtro
     */
    public String getDescription() {
        return "Clases Java";
    }
}
