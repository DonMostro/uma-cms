/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id: GeneradorCodigoException.java,v 1.1 2008/02/25 21:12:26 cupi3 Exp $ 
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n 
 * Licenciado bajo el esquema Academic Free License version 2.1 
 *
 * Proyecto Cupi3 (http://cupi2.uniandes.edu.co)
 * Ejercicio: Tutorial Generaci�n C�digo (n10_paint)
 * Autor: n-calder 
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 */
package uniandes.cupi2.paint.velocity.mundo;

/**
 * Excepci�n generada en el proceso de generaci�n de c�digo
 */
public class GeneradorCodigoException extends Exception {

	/**
	 * @param causa
	 */
	public GeneradorCodigoException(String causa) {
		super(causa);
	}

	/**
	 * @param causa
	 */
	public GeneradorCodigoException(Exception causa) {
		super(causa);
	}

	/**
	 * @param causa
	 * @param e
	 */
	public GeneradorCodigoException(String causa, Exception e) {
		super(causa, e);
	}

}
