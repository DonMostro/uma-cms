/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n 
 * Licenciado bajo el esquema Academic Free License version 2.1 
 *
 * Proyecto Cupi2 (http://cupi2.uniandes.edu.co)
 * Ejercicio: n10_paint
 * Autor: Generado
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 */
package uniandes.cupi2.paint.mundo;

/**
 * C�digo Generado con la m�quina de generaci�n de c�digo Velocity
 */
public class Ejemplo.java  extends uniandes.cupi2.paint.mundo.Figura {
	
	//==========================================================
	// Atributos
	//==========================================================
	
		protected java.awt.Color colorLinea; 
	
		protected java.awt.BasicStroke tipoLinea; 
	
		protected int x1; 
	
		protected int y1; 
	
		protected int x2; 
	
		protected int y2; 
	
		
	//==========================================================
	// M�todos Constructores
	//==========================================================
	
			
	/**
	 *
	 */
	 public Ejemplo.java(  int parametro1  ,  int parametro2  ,  int parametro3  ,  int parametro4  ,  java.awt.Color parametro5  ,  java.awt.BasicStroke parametro6   ) 
	{	
			super( parametro1  ,  parametro2  ,  parametro3  ,  parametro4  ,  parametro5  ,  parametro6  );
	}
	 
			
	/**
	 *
	 */
	 public Ejemplo.java(  java.io.BufferedReader parametro1   ) 
	{	
			super( parametro1  );
	}
	 
		
	//==========================================================
	// M�todos
	//==========================================================
	
		
	/**
	 *
	 */
	 public void dibujar(   java.awt.Graphics2D param1   ,  boolean param2   )
		 	{
	   //TODO completar implementaci�n de acuerdo con la documentaci�n del m�todo
	   	   	 
	 }
		
	/**
	 *
	 */
	 public boolean estaDentro(   int param1   ,  int param2   )
		 	{
	   //TODO completar implementaci�n de acuerdo con la documentaci�n del m�todo
	    return false;
	   	 
	 }
		
	/**
	 *
	 */
	 public java.lang.String darTipoFigura(  )
		 	{
	   //TODO completar implementaci�n de acuerdo con la documentaci�n del m�todo
	    return null; 	 
	 }
		
}