/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id: PanelEditor.java,v 1.1 2008/02/25 06:57:34 cupi3 Exp $ 
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n 
 * Licenciado bajo el esquema Academic Free License version 2.1 
 *
 * Proyecto Cupi2 (http://cupi2.uniandes.edu.co)
 * Ejercicio: n10_paint
 * Autor: Mario S�nchez - 27/09/2005 
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 */
package uniandes.cupi2.paint.interfaz;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.*;

import uniandes.cupi2.paint.mundo.*;

/**
 * Este es el panel que maneja la interacci�n con el mouse y muestra las figuras dibujadas
 */
public class PanelEditor extends JPanel implements MouseListener
{
    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------

    /**
     * Es una referencia al editor en el que se est� haciendo la composici�n
     */
    private Dibujo editor;

    /**
     * Es la coordenada x del primer punto
     */
    private int xSeleccionado;

    /**
     * Es la coordenada y del primer punto
     */
    private int ySeleccionado;

    /**
     * Es una referencia a la clase principal de la interfaz
     */
    private InterfazPaint principal;

    // -----------------------------------------------------------------
    // Constructores
    // -----------------------------------------------------------------

    /**
     * Construye el panel
     * @param ip Es una referencia a la clase principal de la interfaz
     * @param e Es una referencia al editor de la aplicaci�n
     */
    public PanelEditor( InterfazPaint ip, Dibujo e )
    {
        principal = ip;
        editor = e;

        xSeleccionado = -1;
        ySeleccionado = -1;

        addMouseListener( this );

        setDoubleBuffered( true );
        setBorder( new TitledBorder( "" ) );
    }

    // -----------------------------------------------------------------
    // M�todos
    // -----------------------------------------------------------------

    /**
     * Borra el punto seleccionado
     */
    public void borrarPuntos( )
    {
        xSeleccionado = -1;
        ySeleccionado = -1;
    }

    /**
     * Este m�todo se encarga de actualizar la visualizaci�n de la composici�n
     */
    public void actualizar( )
    {
        repaint( );
    }

    /**
     * Este es el m�todo que se encarga de actualizar la visualizaci�n de la composici�n
     * @param g Es la superficie del panel
     */
    public void update( Graphics2D g )
    {
        g.setRenderingHint( RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON );
        g.setColor( getBackground( ) );
        g.fillRect( 0, 0, getWidth( ), getHeight( ) );

        // Dibujar las figuras
        editor.dibujar( g );

        // dibujar el punto seleccionado si lo hay
        if( xSeleccionado != -1 && ySeleccionado != -1 )
        {
            g.setColor( Color.GREEN );
            g.fillOval( xSeleccionado - 2, ySeleccionado - 2, 3, 3 );
        }
    }

    /**
     * Este es el m�todo llamado por la m�quina virtual cuando hay que repintar el panel<br>. <code>super.paint( g )</code> no sabe pintar las figuras, as� que hay que
     * sobrecargar el m�todo.
     * @param g Es la superficie del panel
     */
    public void paintComponent( Graphics g )
    {
        super.paintComponent( g );
        update( ( Graphics2D )g );
    }

    /**
     * Este m�todo se llama cuando se hace click sobre la superficie del editor.
     * @param evento Es el evento del click sobre el editor
     */
    public void mouseClicked( MouseEvent evento )
    {
        if( evento.getButton( ) == MouseEvent.BUTTON1 )
        {
            int opcion = principal.darOpcionSeleccionada( );

            if( opcion == InterfazPaint.SELECCIONAR )
            {
                int x = evento.getX( );
                int y = evento.getY( );
                principal.seleccionar( x, y );

                if( evento.getClickCount( ) > 1 )
                {
                    principal.mostrarVentanaTexto( );
                }
                borrarPuntos( );
            }
            else if( opcion == InterfazPaint.RECTANGULO || opcion == InterfazPaint.OVALO || opcion == InterfazPaint.LINEA )
            {
                if( xSeleccionado == -1 && ySeleccionado == -1 ) // Es el
                // primer
                // punto
                {
                    xSeleccionado = evento.getX( );
                    ySeleccionado = evento.getY( );
                    actualizar( );
                }
                else
                {
                    int x2 = evento.getX( );
                    int y2 = evento.getY( );
                    principal.agregarFigura( xSeleccionado, ySeleccionado, x2, y2 );
                }
            }
        }
    }

    /**
     * Este m�todo no se implementa
     * @param arg0 El evento
     */
    public void mousePressed( MouseEvent arg0 )
    {// No se requiere
    }

    /**
     * Este m�todo no se implementa
     * @param arg0 El evento
     */
    public void mouseReleased( MouseEvent arg0 )
    {// No se requiere
    }

    /**
     * Este m�todo no se implementa
     * @param arg0 El evento
     */
    public void mouseEntered( MouseEvent arg0 )
    {// No se requiere
    }

    /**
     * Este m�todo no se implementa
     * @param arg0 El evento
     */
    public void mouseExited( MouseEvent arg0 )
    {// No se requiere
    }

}